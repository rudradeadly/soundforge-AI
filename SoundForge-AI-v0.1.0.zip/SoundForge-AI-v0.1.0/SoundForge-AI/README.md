# SoundForge AI

**An MCP sound-design toolkit for Claude Code, Codex, OpenCode, and other MCP-compatible agents.**

SoundForge v0.1.0 can:
- Inspect local video metadata and detect hard scene cuts using FFmpeg.
- Generate eight procedural sound-effect types as WAV files.
- Create timestamped, editable audio projects.
- Mix multiple layers into a stereo WAV.
- Export individual stems and a portable `project.json` timeline.

> **Scope honesty:** This is a working MVP foundation, not a finished neural sound-generation product. Its built-in effects are procedural synthesized sounds. Video analysis detects metadata and scene cuts; it does not identify semantic actions such as a person jumping or a camera zooming. The JSON project is portable but is not a native Premiere/After Effects/DaVinci/CapCut project.

## Requirements

- Node.js 20 or newer
- npm
- FFmpeg + ffprobe on PATH (only needed for video inspection)

Check:
```bash
node --version
npm --version
ffmpeg -version
ffprobe -version
```

## Install

```bash
cd SoundForge-AI
npm install
npm run check
```

## Run as an MCP server

```bash
npm start
```

The server uses stdio, so launch it through your agent's MCP configuration. Do not run it in a separate terminal when the agent expects to own the stdio process.

### Claude Code

This repository includes `.mcp.json` and a Claude plugin manifest. From the project directory, Claude Code can load the project MCP server with:

```bash
claude --plugin-dir .
```

If running outside the plugin workflow, configure the server using an absolute path to `src/server.mjs` and command `node`.

### Codex

Add an MCP server entry to your Codex configuration (`~/.codex/config.toml`), adapting the absolute path:

```toml
[mcp_servers.soundforge]
command = "node"
args = ["/ABSOLUTE/PATH/SoundForge-AI/src/server.mjs"]
```

The reusable skill is available at `.agents/skills/soundforge/SKILL.md`. If your Codex installation uses a different skills discovery path/version, copy that folder into its supported project skill directory.

### OpenCode

Add this MCP server to `opencode.json` (or merge it into your existing configuration):

```json
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "soundforge": {
      "type": "local",
      "command": ["node", "/ABSOLUTE/PATH/SoundForge-AI/src/server.mjs"],
      "enabled": true
    }
  }
}
```

The reusable skill is at `.opencode/skills/soundforge/SKILL.md`.

## Available MCP tools

### `soundforge_get_capabilities`
Returns the current feature list and limitations.

### `soundforge_inspect_video`
Input:
```json
{ "video_path": "/absolute/path/to/edit.mp4" }
```
Returns video duration, dimensions, codecs, audio presence, and best-effort hard scene-cut timestamps.

### `soundforge_plan`
Input:
```json
{ "brief": "cinematic tech reveal with a fast zoom, glitch and powerful impact", "duration": 12 }
```
Returns a heuristic event plan. It does not analyze the actual video content.

### `soundforge_generate_sfx`
Input:
```json
{
  "type": "whoosh",
  "output_path": "/absolute/path/whoosh.wav",
  "duration": 0.8,
  "intensity": 0.7,
  "sample_rate": 44100
}
```
Supported types: `whoosh`, `impact`, `riser`, `glitch`, `click`, `rumble`, `sparkle`, `metal_hit`.

### `soundforge_build_project`
Input example:
```json
{
  "project_name": "my-edit",
  "output_dir": "/absolute/path/exports",
  "sample_rate": 44100,
  "events": [
    {
      "name": "camera_sweep",
      "type": "whoosh",
      "start": 0.5,
      "duration": 0.8,
      "intensity": 0.7,
      "gain": 0.8,
      "pan": -0.1,
      "fade_in": 0,
      "fade_out": 0.1,
      "description": "Fast camera move"
    },
    {
      "name": "hero_hit",
      "type": "impact",
      "start": 2.4,
      "duration": 0.9,
      "intensity": 0.9,
      "gain": 0.85,
      "pan": 0
    }
  ]
}
```

Creates:
```text
exports/my-edit/
├── project.json
├── mix.wav
└── sfx/
    ├── 01_camera_sweep.wav
    └── 02_hero_hit.wav
```

## Recommended workflow

1. Ask the agent to inspect the video.
2. Give it a short description of the actual visual events and key timestamps.
3. Ask it to create a sound-design plan.
4. Review/edit the event plan.
5. Generate the project.
6. Listen to `mix.wav`; adjust event start, gain, pan, and duration as needed.
7. Import stems into your editor or DAW.

## Development notes

- Pure Node.js WAV synthesis and mixing; no Python runtime required.
- Video inspection shells out to `ffprobe` and `ffmpeg` using argument arrays (no shell interpolation).
- The MCP server communicates over stdio. Logs should not be written to stdout.
- The output mix is peak-normalized to a conservative ceiling; this is not a mastering chain.
- Event types are intentionally limited for v0.1.0.

## Roadmap

- v0.2: frame sampling and better motion/event analysis.
- v0.3: optional neural SFX provider adapters (user supplies API key).
- v0.4: loudness metering, EQ/filter controls, reverb, and richer automation.
- v0.5: import/export adapters for selected DAWs/editors where supported.

## Troubleshooting

**MCP server fails to start**
- Confirm Node.js 20+.
- Run `npm install`.
- Run `npm run check`.
- Confirm the MCP client points to the absolute `src/server.mjs` path.

**Video inspection fails**
- Install FFmpeg and ensure both `ffmpeg` and `ffprobe` are on PATH.
- Test the video with `ffprobe -v error -show_format input.mp4`.

**No audio sounds in generated effects**
- Use headphones or speakers and check playback volume.
- Try `impact`, `whoosh`, or `metal_hit` at 0.7–0.9 intensity.
- These are synthetic starter effects; they are not recordings.

## License

MIT. See `LICENSE`.
