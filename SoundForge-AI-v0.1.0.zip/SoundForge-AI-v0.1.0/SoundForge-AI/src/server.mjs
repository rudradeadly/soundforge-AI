#!/usr/bin/env node
import path from "node:path";
import os from "node:os";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { synthesizeSfx, writeWav } from "./audio.mjs";
import { inspectVideo } from "./video.mjs";
import { createSoundDesign, planFromPrompt } from "./project.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const server = new McpServer({ name: "soundforge-ai", version: "0.1.0" });
const sfxTypes = ["whoosh", "impact", "riser", "glitch", "click", "rumble", "sparkle", "metal_hit"];

function result(data) {
  return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
}

server.tool(
  "soundforge_inspect_video",
  "Inspect video metadata and detect hard scene cuts with FFmpeg. This does not understand semantic actions; supply event descriptions for accurate sound design.",
  { video_path: z.string().describe("Absolute or relative path to a local video file.") },
  async ({ video_path }) => result(inspectVideo(path.resolve(video_path)))
);

server.tool(
  "soundforge_generate_sfx",
  "Generate a procedural WAV sound effect. Useful for prototypes, placeholder effects, and basic synthetic accents.",
  {
    type: z.enum(sfxTypes),
    output_path: z.string().describe("Where to save the WAV file."),
    duration: z.number().min(0.08).max(12).default(1),
    intensity: z.number().min(0.05).max(1).default(0.7),
    sample_rate: z.number().int().min(22050).max(96000).default(44100)
  },
  async ({ type, output_path, duration, intensity, sample_rate }) => {
    const target = path.resolve(output_path);
    const samples = synthesizeSfx({ type, duration, intensity, sampleRate: sample_rate });
    return result(writeWav(target, samples, sample_rate));
  }
);

server.tool(
  "soundforge_plan",
  "Create a starter sound-design event plan from a creative brief. Treat it as a draft: adjust timestamps to match the actual video.",
  {
    brief: z.string().min(3),
    duration: z.number().min(1).max(600).default(15)
  },
  async ({ brief, duration }) => result({
    duration,
    events: planFromPrompt(brief, duration),
    guidance: "This is a heuristic draft based on keywords, not semantic video understanding. Review every timestamp."
  })
);

server.tool(
  "soundforge_build_project",
  "Generate separate procedural WAV SFX layers, a stereo mix, and an editable JSON project manifest from timestamped events.",
  {
    project_name: z.string().default("soundforge-project"),
    output_dir: z.string().default(path.join(os.homedir(), "SoundForge-Projects")),
    sample_rate: z.number().int().min(22050).max(96000).default(44100),
    events: z.array(z.object({
      name: z.string().optional(),
      type: z.enum(sfxTypes),
      start: z.number().min(0),
      duration: z.number().min(0.08).max(12).default(0.7),
      intensity: z.number().min(0.05).max(1).default(0.7),
      gain: z.number().min(0).max(2).default(0.8),
      pan: z.number().min(-1).max(1).default(0),
      fade_in: z.number().min(0).default(0),
      fade_out: z.number().min(0).default(0.08),
      description: z.string().optional()
    })).min(1).max(200)
  },
  async ({ project_name, output_dir, sample_rate, events }) => {
    const normalized = events.map(e => ({
      ...e, fadeIn: e.fade_in, fadeOut: e.fade_out
    }));
    return result(createSoundDesign({
      events: normalized, outputDir: path.resolve(output_dir), projectName: project_name, sampleRate: sample_rate
    }));
  }
);

server.tool(
  "soundforge_get_capabilities",
  "Explain SoundForge's current capabilities and limitations.",
  {},
  async () => result({
    version: "0.1.0",
    capabilities: ["procedural SFX synthesis", "video metadata inspection", "FFmpeg scene-cut detection", "timestamped layered project creation", "stereo WAV mixing", "JSON project manifest"],
    limitations: [
      "No neural/text-to-audio model is bundled; generated effects are procedural.",
      "No semantic video understanding or automatic object/action recognition.",
      "No direct After Effects, Premiere, DaVinci Resolve, CapCut, or Alight Motion project integration.",
      "No music generation, voice generation, or commercial sample-library licensing."
    ],
    requirements: ["Node.js 20+", "npm install", "FFmpeg and ffprobe for video inspection"]
  })
);

const transport = new StdioServerTransport();
await server.connect(transport);
