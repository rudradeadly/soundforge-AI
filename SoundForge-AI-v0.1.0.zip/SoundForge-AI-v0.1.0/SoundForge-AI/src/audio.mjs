import fs from "node:fs";
import path from "node:path";

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const TAU = Math.PI * 2;

function seededNoise(seed = 1) {
  let s = seed >>> 0;
  return () => {
    s = (1664525 * s + 1013904223) >>> 0;
    return (s / 0xffffffff) * 2 - 1;
  };
}

function envelope(t, duration, attack = 0.01, release = 0.12) {
  const a = attack > 0 ? Math.min(1, t / attack) : 1;
  const r = release > 0 ? Math.min(1, (duration - t) / release) : 1;
  return Math.max(0, Math.min(a, r));
}

function oscillator(type, phase) {
  if (type === "square") return Math.sin(phase) >= 0 ? 1 : -1;
  if (type === "triangle") return (2 / Math.PI) * Math.asin(Math.sin(phase));
  return Math.sin(phase);
}

export function synthesizeSfx({ type, duration = 1, intensity = 0.7, sampleRate = 44100, seed = 17 }) {
  const allowed = ["whoosh", "impact", "riser", "glitch", "click", "rumble", "sparkle", "metal_hit"];
  if (!allowed.includes(type)) throw new Error(`Unsupported SFX type. Choose: ${allowed.join(", ")}`);
  duration = clamp(Number(duration) || 1, 0.08, 12);
  intensity = clamp(Number(intensity) || 0.7, 0.05, 1);
  const count = Math.floor(duration * sampleRate);
  const out = new Float32Array(count);
  const noise = seededNoise(seed);
  let smoothNoise = 0;
  let phase = 0;
  let phase2 = 0;

  for (let i = 0; i < count; i++) {
    const t = i / sampleRate;
    const p = t / duration;
    const env = envelope(t, duration, Math.min(0.08, duration * 0.12), Math.min(0.35, duration * 0.4));
    const n = noise();
    smoothNoise = smoothNoise * 0.82 + n * 0.18;
    let s = 0;

    if (type === "whoosh") {
      const sweep = Math.sin(Math.PI * p);
      const cutoffMotion = 250 + 5200 * p;
      phase += TAU * cutoffMotion / sampleRate;
      s = (n * 0.62 + Math.sin(phase) * 0.38) * sweep * env;
    } else if (type === "impact") {
      const f = 48 + 105 * Math.exp(-t * 13);
      phase += TAU * f / sampleRate;
      s = (Math.sin(phase) * 0.78 + n * 0.22) * Math.exp(-t * 9) * env;
    } else if (type === "riser") {
      const f = 110 + 1500 * p * p;
      phase += TAU * f / sampleRate;
      s = (Math.sin(phase) * 0.42 + smoothNoise * 0.58) * p * p * env;
    } else if (type === "glitch") {
      const gate = (Math.floor(t * 24) % 5 === 0) ? 1 : 0.16;
      const f = 180 + (Math.floor(t * 31) % 7) * 93;
      phase += TAU * f / sampleRate;
      s = (oscillator("square", phase) * 0.48 + n * 0.52) * gate * env;
    } else if (type === "click") {
      const transient = Math.exp(-t * 95);
      phase += TAU * 1800 / sampleRate;
      s = (n * 0.5 + Math.sin(phase) * 0.5) * transient;
    } else if (type === "rumble") {
      const f = 34 + 12 * Math.sin(t * 2.1);
      phase += TAU * f / sampleRate;
      s = (Math.sin(phase) * 0.68 + smoothNoise * 0.32) * env;
    } else if (type === "sparkle") {
      const f = 900 + 2600 * Math.pow(Math.sin(t * 17), 2);
      phase += TAU * f / sampleRate;
      s = (Math.sin(phase) * 0.6 + n * 0.4) * Math.exp(-t * 2.4) * env;
    } else if (type === "metal_hit") {
      const f1 = 430 + 20 * Math.exp(-t * 20);
      const f2 = 1130 + 80 * Math.exp(-t * 8);
      phase += TAU * f1 / sampleRate;
      phase2 += TAU * f2 / sampleRate;
      s = (Math.sin(phase) * 0.62 + Math.sin(phase2) * 0.38) * Math.exp(-t * 5.5) * env;
    }

    out[i] = clamp(s * intensity * 0.82, -0.98, 0.98);
  }
  return out;
}

export function writeWav(filePath, samples, sampleRate = 44100) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const dataBytes = samples.length * 2;
  const buffer = Buffer.alloc(44 + dataBytes);
  buffer.write("RIFF", 0);
  buffer.writeUInt32LE(36 + dataBytes, 4);
  buffer.write("WAVE", 8);
  buffer.write("fmt ", 12);
  buffer.writeUInt32LE(16, 16);
  buffer.writeUInt16LE(1, 20);
  buffer.writeUInt16LE(1, 22);
  buffer.writeUInt32LE(sampleRate, 24);
  buffer.writeUInt32LE(sampleRate * 2, 28);
  buffer.writeUInt16LE(2, 32);
  buffer.writeUInt16LE(16, 34);
  buffer.write("data", 36);
  buffer.writeUInt32LE(dataBytes, 40);
  for (let i = 0; i < samples.length; i++) {
    const v = Math.round(clamp(samples[i], -1, 1) * 32767);
    buffer.writeInt16LE(v, 44 + i * 2);
  }
  fs.writeFileSync(filePath, buffer);
  return { path: filePath, sampleRate, duration: samples.length / sampleRate };
}

export function mixTracks(tracks, totalDuration, sampleRate = 44100) {
  const length = Math.ceil(totalDuration * sampleRate);
  const left = new Float32Array(length);
  const right = new Float32Array(length);

  for (const track of tracks) {
    const start = Math.max(0, Math.floor((track.start || 0) * sampleRate));
    const gain = clamp(Number(track.gain ?? 0.8), 0, 2);
    const pan = clamp(Number(track.pan ?? 0), -1, 1);
    const lg = gain * Math.cos((pan + 1) * Math.PI / 4);
    const rg = gain * Math.sin((pan + 1) * Math.PI / 4);
    const fadeIn = Math.max(0, Number(track.fadeIn || 0));
    const fadeOut = Math.max(0, Number(track.fadeOut || 0));
    const samples = track.samples;
    for (let i = 0; i < samples.length && start + i < length; i++) {
      const t = i / sampleRate;
      const remaining = (samples.length - i) / sampleRate;
      let e = 1;
      if (fadeIn > 0) e *= Math.min(1, t / fadeIn);
      if (fadeOut > 0) e *= Math.min(1, remaining / fadeOut);
      left[start + i] += samples[i] * lg * e;
      right[start + i] += samples[i] * rg * e;
    }
  }

  // Gentle peak normalization, preserving stereo.
  let peak = 0;
  for (let i = 0; i < length; i++) peak = Math.max(peak, Math.abs(left[i]), Math.abs(right[i]));
  const norm = peak > 0.94 ? 0.94 / peak : 1;
  const interleaved = new Float32Array(length * 2);
  for (let i = 0; i < length; i++) {
    interleaved[i * 2] = left[i] * norm;
    interleaved[i * 2 + 1] = right[i] * norm;
  }
  return interleaved;
}

export function writeStereoWav(filePath, samples, sampleRate = 44100) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const dataBytes = samples.length * 2;
  const buffer = Buffer.alloc(44 + dataBytes);
  buffer.write("RIFF", 0); buffer.writeUInt32LE(36 + dataBytes, 4);
  buffer.write("WAVE", 8); buffer.write("fmt ", 12);
  buffer.writeUInt32LE(16, 16); buffer.writeUInt16LE(1, 20);
  buffer.writeUInt16LE(2, 22); buffer.writeUInt32LE(sampleRate, 24);
  buffer.writeUInt32LE(sampleRate * 4, 28); buffer.writeUInt16LE(4, 32);
  buffer.writeUInt16LE(16, 34); buffer.write("data", 36);
  buffer.writeUInt32LE(dataBytes, 40);
  for (let i = 0; i < samples.length; i++) {
    buffer.writeInt16LE(Math.round(clamp(samples[i], -1, 1) * 32767), 44 + i * 2);
  }
  fs.writeFileSync(filePath, buffer);
  return { path: filePath, sampleRate, channels: 2, duration: samples.length / (sampleRate * 2) };
}
