import { spawnSync } from "node:child_process";
import fs from "node:fs";

function run(command, args, timeout = 120000) {
  const result = spawnSync(command, args, { encoding: "utf8", timeout, maxBuffer: 20 * 1024 * 1024 });
  if (result.error) throw new Error(`${command} failed: ${result.error.message}`);
  if (result.status !== 0) throw new Error(`${command} exited ${result.status}: ${(result.stderr || result.stdout || "").slice(-3000)}`);
  return result.stdout || "";
}

export function inspectVideo(videoPath) {
  if (!fs.existsSync(videoPath)) throw new Error(`Video file not found: ${videoPath}`);
  let probe;
  try {
    probe = JSON.parse(run("ffprobe", [
      "-v", "error", "-show_entries",
      "format=duration:stream=codec_type,width,height,r_frame_rate,codec_name",
      "-of", "json", videoPath
    ]));
  } catch (e) {
    throw new Error(`Could not inspect video. Install FFmpeg (ffprobe must be on PATH). Details: ${e.message}`);
  }

  const videoStream = (probe.streams || []).find(s => s.codec_type === "video");
  const audioStream = (probe.streams || []).find(s => s.codec_type === "audio");
  const duration = Number(probe.format?.duration || 0);
  let sceneCuts = [];
  try {
    const output = run("ffmpeg", [
      "-hide_banner", "-i", videoPath, "-vf", "select='gt(scene,0.28)',showinfo",
      "-an", "-f", "null", "-"
    ]);
    sceneCuts = [...output.matchAll(/pts_time:([0-9.]+)/g)].map(m => Number(m[1])).filter(Number.isFinite);
  } catch {
    // Scene detection is best-effort; metadata remains useful if this filter fails.
  }

  return {
    file: videoPath,
    duration,
    hasAudio: Boolean(audioStream),
    video: videoStream ? {
      codec: videoStream.codec_name,
      width: Number(videoStream.width),
      height: Number(videoStream.height),
      frameRate: videoStream.r_frame_rate
    } : null,
    audio: audioStream ? { codec: audioStream.codec_name } : null,
    sceneCuts,
    note: "Scene cuts are visual edit boundaries, not semantic event recognition. Describe motion/impacts separately for accurate sound placement."
  };
}
