import fs from "node:fs";
import path from "node:path";
import { synthesizeSfx, writeWav, mixTracks, writeStereoWav } from "./audio.mjs";

const TYPES = ["whoosh", "impact", "riser", "glitch", "click", "rumble", "sparkle", "metal_hit"];

export function validateEvents(events) {
  if (!Array.isArray(events) || events.length === 0) throw new Error("Provide at least one event.");
  return events.map((e, i) => {
    if (!TYPES.includes(e.type)) throw new Error(`Event ${i + 1}: type must be one of ${TYPES.join(", ")}`);
    const start = Number(e.start);
    const duration = Number(e.duration ?? 0.7);
    if (!Number.isFinite(start) || start < 0) throw new Error(`Event ${i + 1}: start must be a non-negative number.`);
    if (!Number.isFinite(duration) || duration <= 0 || duration > 12) throw new Error(`Event ${i + 1}: duration must be between 0 and 12 seconds.`);
    return {
      name: String(e.name || `${e.type}-${i + 1}`).replace(/[^a-zA-Z0-9_-]/g, "_"),
      type: e.type,
      start,
      duration,
      intensity: Math.min(1, Math.max(0.05, Number(e.intensity ?? 0.7))),
      gain: Math.min(2, Math.max(0, Number(e.gain ?? 0.8))),
      pan: Math.min(1, Math.max(-1, Number(e.pan ?? 0))),
      fadeIn: Math.max(0, Number(e.fadeIn ?? 0)),
      fadeOut: Math.max(0, Number(e.fadeOut ?? 0.08)),
      description: String(e.description || "")
    };
  });
}

export function createSoundDesign({ events, outputDir, projectName = "soundforge-project", sampleRate = 44100 }) {
  const safeName = projectName.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 60) || "soundforge-project";
  const projectDir = path.resolve(outputDir, safeName);
  const sfxDir = path.join(projectDir, "sfx");
  fs.mkdirSync(sfxDir, { recursive: true });
  const normalized = validateEvents(events);
  const tracks = [];
  const projectEvents = [];
  let totalDuration = 0;

  normalized.forEach((event, i) => {
    const samples = synthesizeSfx({
      type: event.type, duration: event.duration, intensity: event.intensity,
      sampleRate, seed: 100 + i * 19
    });
    const filename = `${String(i + 1).padStart(2, "0")}_${event.name}.wav`;
    const sfxPath = path.join(sfxDir, filename);
    writeWav(sfxPath, samples, sampleRate);
    tracks.push({ samples, start: event.start, gain: event.gain, pan: event.pan, fadeIn: event.fadeIn, fadeOut: event.fadeOut });
    totalDuration = Math.max(totalDuration, event.start + event.duration);
    projectEvents.push({
      ...event,
      file: `sfx/${filename}`,
      sampleRate,
      channels: 1
    });
  });

  const mixed = mixTracks(tracks, totalDuration, sampleRate);
  const mixPath = path.join(projectDir, "mix.wav");
  writeStereoWav(mixPath, mixed, sampleRate);

  const manifest = {
    format: "soundforge-project",
    version: "1.0",
    projectName: safeName,
    sampleRate,
    channels: 2,
    duration: totalDuration,
    mix: "mix.wav",
    events: projectEvents,
    limitations: [
      "Generated SFX are procedural synthesized placeholders, not recorded Foley or neural audio generation.",
      "Review the mix and adjust event timing, gain, and pan before commercial delivery."
    ]
  };
  const manifestPath = path.join(projectDir, "project.json");
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));
  return {
    projectDir,
    manifestPath,
    mixPath,
    duration: totalDuration,
    eventCount: projectEvents.length,
    sfxFiles: projectEvents.map(e => path.join(projectDir, e.file))
  };
}

export function planFromPrompt(prompt, duration = 15) {
  const p = String(prompt || "").toLowerCase();
  const events = [];
  const add = (type, start, d, intensity, description) => events.push({ type, start, duration: d, intensity, description });
  if (/zoom|whoosh|sweep|fast|motion|transition/.test(p)) {
    add("whoosh", 0.2, 0.8, 0.65, "Opening motion sweep");
    add("whoosh", Math.max(1, duration * 0.35), 0.65, 0.55, "Mid-edit transition");
  }
  if (/impact|hit|punch|powerful|dramatic|cinematic/.test(p)) {
    add("impact", Math.max(0.5, duration * 0.55), 0.9, 0.9, "Main cinematic impact");
    add("rumble", Math.max(0.5, duration * 0.55), 1.4, 0.55, "Low-end impact layer");
  }
  if (/rise|build|buildup|reveal|drop/.test(p)) add("riser", Math.max(0, duration * 0.62 - 1.5), 1.5, 0.7, "Build into reveal");
  if (/glitch|digital|tech|cyber/.test(p)) add("glitch", Math.max(0.3, duration * 0.2), 0.7, 0.6, "Digital glitch accent");
  if (/text|title|logo|pop/.test(p)) add("click", Math.max(0.4, duration * 0.78), 0.18, 0.65, "Title or logo accent");
  if (events.length === 0) {
    add("whoosh", 0.2, 0.7, 0.55, "Intro sweep");
    add("click", Math.min(duration - 0.1, 1.2), 0.18, 0.5, "Accent");
    add("impact", Math.max(0, duration - 1.2), 0.9, 0.7, "Closing impact");
  }
  return events.filter(e => e.start + e.duration <= duration + 0.01);
}
