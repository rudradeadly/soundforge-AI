import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { synthesizeSfx, writeWav } from "../src/audio.mjs";
import { createSoundDesign, planFromPrompt, validateEvents } from "../src/project.mjs";

test("synthesizes supported SFX and returns samples", () => {
  const samples = synthesizeSfx({ type: "impact", duration: 0.3, intensity: 0.8 });
  assert.ok(samples.length > 1000);
  assert.ok(samples.some(v => Math.abs(v) > 0.01));
});

test("writes a valid PCM WAV header", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "soundforge-test-"));
  const file = path.join(dir, "test.wav");
  const samples = synthesizeSfx({ type: "click", duration: 0.2 });
  writeWav(file, samples);
  const b = fs.readFileSync(file);
  assert.equal(b.toString("ascii", 0, 4), "RIFF");
  assert.equal(b.toString("ascii", 8, 12), "WAVE");
  fs.rmSync(dir, { recursive: true, force: true });
});

test("validates events and creates editable project outputs", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "soundforge-project-"));
  const result = createSoundDesign({
    outputDir: dir,
    projectName: "test-project",
    events: [{ type: "whoosh", start: 0, duration: 0.4 }]
  });
  assert.ok(fs.existsSync(result.mixPath));
  assert.ok(fs.existsSync(result.manifestPath));
  const manifest = JSON.parse(fs.readFileSync(result.manifestPath, "utf8"));
  assert.equal(manifest.events.length, 1);
  fs.rmSync(dir, { recursive: true, force: true });
});

test("prompt planner returns a draft", () => {
  const events = planFromPrompt("cinematic zoom with glitch and impact", 10);
  assert.ok(events.length >= 2);
  assert.ok(events.every(e => e.start >= 0 && e.start + e.duration <= 10.01));
});

test("rejects invalid event types", () => {
  assert.throws(() => validateEvents([{ type: "bad", start: 0 }]));
});
